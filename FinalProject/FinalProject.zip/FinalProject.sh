#!/bin/bash
java -jar FinalProject.jar